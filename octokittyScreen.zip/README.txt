#############################################################
# PUT TOGETHER BY DWALF - 11SEP2021
# WARNING NOTE: THIS IS NOT A PLUGIN - DO NOT USE IT AS A OCTOPRINT PLUGIN
#
# NAME OCTOKITTY_SCREEN for PC DISPLAYS ON Pi - (README)
# VERSION 1.0 - NOT FOR COMMERCAIL USE - PERSONAL USE ONLY
# WITHOUT WARRNETY OR SUPPORT
# USE AT OWN RISK AND LIABILITY
#
# THANKS EVERYONE - ONLY ONE HOTEND tool0 SUPPORTED
# WORKS WITH OCTOPRINT 1.6 (0.18.0 Octoprint) and PY3
# TIP ME AT https://www.thingiverse.com/dwalf/designs
#
# REQUIRED ALL FILES IN '/home/pi' FOLDER
#
# SEE README FILE
#
#############################################################

THIS VERSION IS FOR A PC SCREEN CONNECTED TO YOUR PI
IT SHOWS YOU INFO FOR UPTO 3 SERVERS (you can mod the file and get more)

Copy the script file to /home/pi/ folder

make it executable

cmd = sudo chmod +x octokittyscreen

Edit the file and change settings (supports 3 servers but you could copy more instances and mod the file to get more)

cmd = sudo nano octokittyscreen

Edit the settings by looking for <--------------------------------- arrows
Enable the servers

enter the servers IP address

get the API KEY from each server and enter them in the file

Run from command line

cmd = ./octokittyscreen
